#pip install pyspark==2.4.6
#pip install pandas
#pip install pysolr
import argparse
from pyspark.sql import SparkSession
from pyspark.streaming import StreamingContext
from pyspark.sql import SQLContext
import pysolr
import json
import requests

##Invoke it using the below command
##spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.4.6 trade-stream.py -f /var/secrets/kafka.properties -s n
## f is for properties file
## s is for whether kafka is security enabled or not
##

## Few pointers: kafka parameters are very important, pay attention to the key values ex: kafka.security.protocol
## when you run spark-submit, we need to pass the package details, else it will not work.
## this script works with python 3.7 (not with 3.8) and kafak 0-10 (0-8 lot of things are deprecated.
## JAVA_HOME needs to be set within the container

def insertSolr( batch_df, batch_id):
    print('in insertSolr function')
    solrhost = conf['solrhost']
    solrcollectionurl = 'http://' + solrhost + '/solr/sparktrades'

    def f(x):
        trades_list = []
        final_dictionary = json.loads(x['value'])
        trades = final_dictionary
        del (trades['timeNanoPart'],trades['sequence'],trades['exchangeCode'],trades['dayVolume'],trades['dayTurnover'],trades['size'], trades['tickDirection'], trades['extendedTradingHours'], trades['eventTime'])
        trades_list.append(trades)
        print(trades_list)

        solrcon = pysolr.Solr(solrcollectionurl, always_commit=True, timeout=10)
        solrcon.ping()
        solrcon.add(trades_list)

    fore = batch_df.foreach(f)


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
             description="Confluent Python Client example to produce messages \
                  to Confluent Cloud")
    parser._action_groups.pop()
    required = parser.add_argument_group('required arguments')
    required.add_argument('-f',
                          dest="config_file",
                          help="path to Confluent Cloud configuration file",
                          required=True)
    required.add_argument('-s',
                          dest="security_enabled",
                          help="Specify if kafka is security enabled y/n",
                          required=True)
    args = parser.parse_args()
    return args

def read_config(config_file):
    """Read Confluent Cloud configuration for librdkafka clients"""
    conf = {}
    with open(config_file) as fh:
        for line in fh:
            line = line.strip()
            if len(line) != 0 and line[0] != "#":
                parameter, value = line.strip().split('=', 1)
                conf[parameter] = value.strip()

    return conf



spark = SparkSession.builder.appName('PythonStreamingDirectKafkaSolr').getOrCreate()
sc = spark.sparkContext
ssc = StreamingContext(sc, 5)
sqlContext = SQLContext(sparkContext=sc)

KAFKA_TOPIC_NAME_CONS = "trades"

args = parse_args()
config_file = args.config_file
security_enabled = args.security_enabled
conf = read_config(config_file)
solrhost = conf['solrhost']

create_request_url = 'http://' + solrhost + '/solr/admin/collections?action=CREATE&name=sparktrades&numShards=1&replicationFactor=1'

#Creating sparktrades
resp = requests.get(create_request_url)
print(resp.text)

#  Creating  readstream DataFrame :
if security_enabled == 'y':
    df = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", conf['bootstrap.servers']) \
        .option("subscribe", KAFKA_TOPIC_NAME_CONS) \
        .option("startingOffsets", "earliest") \
        .option("kafka.security.protocol", conf['security.protocol']) \
        .option("kafka.sasl.mechanism", conf['sasl.mechanism']) \
        .option("kafka.client.id", "Client_id") \
        .option("kafka.sasl.jaas.config", conf['sasl.jaas.config']) \
        .load()
else:
    df = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", conf['bootstrap.servers']) \
        .option("subscribe", KAFKA_TOPIC_NAME_CONS) \
        .option("startingOffsets", "earliest") \
        .option("kafka.client.id", "Client_id") \
        .load()


df1 = df.selectExpr( "CAST(value AS STRING)")

#  Creating  Writestream DataFrame :
df1.writeStream \
   .option("path","target_directory") \
   .format("csv") \
   .option("checkpointLocation","chkpint_directory") \
   .outputMode("append") \
   .foreachBatch(insertSolr)\
   .start()

#ssc.start()
ssc.awaitTermination()


